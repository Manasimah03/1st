from flask import Flask, request, send_file, render_template, url_for
import os
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from PIL import Image
import qrcode  
import io

app = Flask(__name__)

# Set a secret key for the AES encryption
key = get_random_bytes(32)  # AES-256 key

# Encrypt image function
def encrypt_image(image_data):
    cipher = AES.new(key, AES.MODE_CBC)
    padded_data = pad(image_data, AES.block_size)
    encrypted_data = cipher.encrypt(padded_data)
    return cipher.iv + encrypted_data  # Prepend IV to encrypted data

# Decrypt image function
def decrypt_image(encrypted_data):
    iv = encrypted_data[:16]  # Extract the IV
    encrypted_data = encrypted_data[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_data = unpad(cipher.decrypt(encrypted_data), AES.block_size)
    return decrypted_data

# Route to serve the HTML page
@app.route('/')
def index():
    return render_template('index.html')

# Route for uploading and encrypting an image
@app.route('/upload/encrypt', methods=['POST'])
def upload_and_encrypt():
    if 'image' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['image']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    # Read image as bytes
    image_data = file.read()

    # Encrypt the image
    encrypted_image = encrypt_image(image_data)
    
    # Save encrypted image to the static directory
    encrypted_image_path = os.path.join('static', 'encrypted_image.png')
    with open(encrypted_image_path, 'wb') as enc_file:
        enc_file.write(encrypted_image)

    # Save QR code to the static directory
    qr_code_path = os.path.join('static', 'qr_code.png')
    qr = qrcode.make(key.hex())  # Generate QR code for key
    qr.save(qr_code_path)

    return render_template('download.html', encrypted_image_url=url_for('static', filename='encrypted_image.png'), qr_code_url=url_for('static', filename='qr_code.png'))

# Route for uploading and decrypting an image
@app.route('/upload/decrypt', methods=['POST'])
def upload_and_decrypt():
    if 'image' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['image']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    # Read encrypted image as bytes
    encrypted_data = file.read()

    # Decrypt the image
    decrypted_image_data = decrypt_image(encrypted_data)

    # Convert byte data to an image and save
    decrypted_image = Image.open(io.BytesIO(decrypted_image_data))
    decrypted_image_path = os.path.join('static', 'decrypted_image.png')
    decrypted_image.save(decrypted_image_path)

    return send_file(decrypted_image_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
